src:
vending_machine_2/3本身即为包含了所有模块的设计文件，点开里面有top module, vending machine , time divider等等
下板验证拆成了两部分（视频太大，虽说就2min）

0报告文档：
内含所有的报告、心得总结等，重要处已标红或加粗或大写

project_5.4.2:
所有原始工程文件

backup:
重要的备份文件，建议阅读